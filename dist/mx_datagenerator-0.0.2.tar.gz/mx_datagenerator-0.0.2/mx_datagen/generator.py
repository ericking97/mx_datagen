# -*- coding: utf-8 -*-
"""Returns functions"""
from .names import GenNames

class Name():
    """Datagenerator class"""

    def male_fullname(self):
        """Returns a male fullname"""
        first_name = GenNames().create_first_name('male')
        paternal_surname = GenNames().create_surname()
        maternal_surname = GenNames().create_surname()
        fullname = first_name + ' ' + paternal_surname + ' ' + maternal_surname
        return fullname

    def female_fullname(self):
        """Returns a female fullname"""
        first_name = GenNames().create_first_name('female')
        paternal_surname = GenNames().create_surname()
        maternal_surname = GenNames().create_surname()
        fullname = first_name + ' ' + paternal_surname + ' ' + maternal_surname
        return fullname

    def male_first_name(self, *args):
        """Returns a male first name"""
        print args

