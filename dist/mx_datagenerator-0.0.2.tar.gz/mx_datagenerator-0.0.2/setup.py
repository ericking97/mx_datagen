# -*- coding: utf-8 -*-
from setuptools import setup

setup(name='mx_datagenerator',
      version='0.0.2',
      description='Generador de datos específicamente creado para México',
      url='https://github.com/ericking97/MX_datagen.git',
      author='ericking97',
      author_email='ericking97@hotmail.com',
      license='MIT',
      packages=['mx_datagen'],
      zip_safe=False)
